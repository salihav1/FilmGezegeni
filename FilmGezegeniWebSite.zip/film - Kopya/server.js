const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// --- ARA YAZILIMLAR (MIDDLEWARE) ---
app.use(cors());
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname)); // HTML, CSS ve resim dosyalarını sunar

// --- MYSQL BAĞLANTISI ---
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12345678', // Senin belirlediğin /* şifre */
    database: 'FilmGezegeniDB'
});

db.connect(err => {
    if (err) {
        console.error('Veritabanı bağlantı hatası: ', err.message);
        return;
    }
    console.log('-----------------------------------------');
    console.log('MySQL Bağlantısı Başarılı! FilmGezegeniDB hazır.');
});

// --- API ENDPOINT'LERİ ---

// 1. Kayıt Olma (Register)
app.post('/api/kayit', (req, res) => {
    const { adSoyad, eposta, sifre } = req.body;
    
    // Veritabanına kullanıcıyı ekleyen sorgu
    const sql = 'INSERT INTO Kullanicilar (kullanici_adi, eposta, sifre) VALUES (?, ?, ?)';
    
    db.query(sql, [adSoyad, eposta, sifre], (err, result) => {
        if (err) {
            console.error('Kayıt Hatası:', err.message);
            return res.status(500).json({ message: 'E-posta zaten kayıtlı veya sistem hatası.' });
        }
        res.status(200).json({ message: 'Kayıt başarıyla oluşturuldu!' });
    });
});

// 2. Giriş Yapma (Login)
app.post('/api/login', (req, res) => {
    const { eposta, sifre } = req.body;
    
    // E-posta ve şifre kontrolü yapan sorgu
    const sql = 'SELECT * FROM Kullanicilar WHERE eposta = ? AND sifre = ?';

    db.query(sql, [eposta, sifre], (err, results) => {
        if (err) {
            console.error('Login Hatası:', err.message);
            return res.status(500).json({ message: 'Sunucu hatası oluştu.' });
        }

        if (results.length > 0) {
            // Kullanıcı bulunduysa başarılı yanıt dön
            res.status(200).json({ 
                message: 'Giriş başarılı!', 
                user: results[0].kullanici_adi,
                userId: results[0].id
            });
        } else {
            // Kullanıcı bulunamadıysa hata dön
            res.status(401).json({ message: 'E-posta veya şifre hatalı!' });
        }
    });
});

// 3. Kullanıcı Bilgilerini Getir (ID ile)
app.get('/api/user/:id', (req, res) => {
    const userId = req.params.id;
    
    const sql = 'SELECT kullanici_adi FROM Kullanicilar WHERE id = ?';
    
    db.query(sql, [userId], (err, results) => {
        if (err) {
            console.error('Kullanıcı Getirme Hatası:', err.message);
            return res.status(500).json({ message: 'Sunucu hatası oluştu.' });
        }

        if (results.length > 0) {
            res.status(200).json({ kullanici_adi: results[0].kullanici_adi });
        } else {
            res.status(404).json({ message: 'Kullanıcı bulunamadı.' });
        }
    });
});

// --- ANA SAYFA YÖNLENDİRMESİ ---
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// --- SUNUCUYU BAŞLAT ---
app.listen(port, () => {
    console.log(`Sistem Aktif: http://localhost:${port}`);
    console.log(`-----------------------------------------`);
});