CREATE DATABASE IF NOT EXISTS FilmGezegeniDB;
USE FilmGezegeniDB;


CREATE TABLE IF NOT EXISTS Kullanicilar (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    kullanici_adi VARCHAR(50) NOT NULL UNIQUE,
    sifre VARCHAR(255) NOT NULL, 
    eposta VARCHAR(100),
    kayit_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO Kullanicilar (kullanici_adi, sifre, eposta)
VALUES ('admin', '123456', 'admin@filmgezegeni.com');


SELECT * FROM Kullanicilar;
ALTER TABLE Kullanicilar ADD COLUMN eposta VARCHAR(100);
USE FilmGezegeniDB;

CREATE TABLE IF NOT EXISTS Kullanicilar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kullanici_adi VARCHAR(100), 
    eposta VARCHAR(100) UNIQUE,
    sifre VARCHAR(100),
    kayit_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
DESC Kullanicilar;
DROP TABLE Kullanicilar;

CREATE TABLE Kullanicilar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kullanici_adi VARCHAR(100),
    eposta VARCHAR(100) UNIQUE,
    sifre VARCHAR(100),
    kayit_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
SELECT * FROM Kullanicilar;
USE FilmGezegeniDB; 
SELECT * FROM Kullanicilar LIMIT 0, 1000;
DELETE FROM Kullanicilar WHERE eposta = 'admin@filmgezegeni.com';
